package com.booking_service.booking_service.client;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.List;

@Component
public class HttpRoomCatalogClient implements RoomCatalogClient {

    private final RestClient restClient;
    private final String serviceName;

    public HttpRoomCatalogClient(
            RestClient.Builder restClientBuilder,
            @Value("${room-service.base-url}") String roomServiceBaseUrl,
            @Value("${spring.application.name}") String serviceName
    ) {
        this.restClient = restClientBuilder.baseUrl(roomServiceBaseUrl).build();
        this.serviceName = serviceName;
    }

    @Override
    @Retry(name = "roomServiceRetry", fallbackMethod = "fallbackRooms")
    @CircuitBreaker(name = "roomServiceCircuit", fallbackMethod = "fallbackRooms")
    public List<RoomSummary> getAvailableRooms(String roomType) {
        return restClient
                .get()
                .uri(uriBuilder -> uriBuilder.path("/api/rooms/available")
                        .queryParam("type", roomType)
                        .build())
                .retrieve()
                .body(new ParameterizedTypeReference<>() {});
    }

    private List<RoomSummary> fallbackRooms(String roomType, Throwable t) {
        System.err.println("[" + serviceName + "] room-service fallback: " + t.getMessage());
        return List.of();
    }
}

