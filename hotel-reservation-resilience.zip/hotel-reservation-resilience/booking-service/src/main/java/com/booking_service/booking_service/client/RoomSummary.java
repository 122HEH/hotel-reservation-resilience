package com.booking_service.booking_service.client;

public record RoomSummary(
        Long id,
        String type,
        double pricePerNight
) {}

