package com.booking_service.booking_service.entity;


import jakarta.persistence.*;

@Entity
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String guestName;
    private String roomType;
    private Long roomId;
    private int nights;
    private double totalPrice;

    public Booking() {}

    public Booking(String guestName, String roomType, Long roomId, int nights, double totalPrice) {
        this.guestName = guestName;
        this.roomType = roomType;
        this.roomId = roomId;
        this.nights = nights;
        this.totalPrice = totalPrice;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getGuestName() { return guestName; }
    public void setGuestName(String g) { this.guestName = g; }
    public String getRoomType() { return roomType; }
    public void setRoomType(String r) { this.roomType = r; }
    public Long getRoomId() { return roomId; }
    public void setRoomId(Long roomId) { this.roomId = roomId; }
    public int getNights() { return nights; }
    public void setNights(int n) { this.nights = n; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
}