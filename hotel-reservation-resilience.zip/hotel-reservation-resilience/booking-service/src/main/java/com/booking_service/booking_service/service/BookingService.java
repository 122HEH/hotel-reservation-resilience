package com.booking_service.booking_service.service;

import com.booking_service.booking_service.entity.Booking;
import com.booking_service.booking_service.client.RoomCatalogClient;
import com.booking_service.booking_service.client.RoomSummary;
import com.booking_service.booking_service.factory.RoomSelectionStrategyFactory;
import com.booking_service.booking_service.repository.BookingRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService implements BookingUseCase {

    private final BookingRepository repository;
    private final RoomCatalogClient roomCatalogClient;
    private final RoomSelectionStrategyFactory strategyFactory;
    private final String serviceName;

    public BookingService(
            BookingRepository repository,
            RoomCatalogClient roomCatalogClient,
            RoomSelectionStrategyFactory strategyFactory,
            @Value("${spring.application.name}") String serviceName
    ) {
        this.repository = repository;
        this.roomCatalogClient = roomCatalogClient;
        this.strategyFactory = strategyFactory;
        this.serviceName = serviceName;
    }

    @CircuitBreaker(name = "bookingService", fallbackMethod = "fallbackGetAll")
    @Override
    public List<Booking> getAllBookings() {
        return repository.findAll();
    }

    @CircuitBreaker(name = "bookingService", fallbackMethod = "fallbackSave")
    @Override
    public Booking createBooking(Booking booking) {
        List<RoomSummary> availableRooms = roomCatalogClient.getAvailableRooms(booking.getRoomType());
        Optional<RoomSummary> selected = strategyFactory.getStrategy().select(availableRooms);
        if (selected.isEmpty()) {
            throw new IllegalStateException("No available room for type=" + booking.getRoomType());
        }

        RoomSummary room = selected.get();
        booking.setRoomId(room.id());
        booking.setTotalPrice(room.pricePerNight() * booking.getNights());
        return repository.save(booking);
    }

    public List<Booking> fallbackGetAll(Throwable t) {
        System.err.println("[" + serviceName + "] Circuit Breaker : " + t.getMessage());
        return List.of();
    }

    public Booking fallbackSave(Booking b, Throwable t) {
        System.err.println("[" + serviceName + "] Circuit Breaker sur création.");
        return null;
    }
}