package com.booking_service.booking_service.factory;

import com.booking_service.booking_service.strategy.RoomSelectionStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class RoomSelectionStrategyFactory {

    private final ApplicationContext applicationContext;
    private final String selectionKey;

    public RoomSelectionStrategyFactory(
            ApplicationContext applicationContext,
            @Value("${booking.room-selection-strategy:CHEAPEST}") String selectionKey
    ) {
        this.applicationContext = applicationContext;
        this.selectionKey = selectionKey;
    }

    public RoomSelectionStrategy getStrategy() {
        if (applicationContext.containsBean(selectionKey)) {
            return applicationContext.getBean(selectionKey, RoomSelectionStrategy.class);
        }
        return applicationContext.getBean("CHEAPEST", RoomSelectionStrategy.class);
    }
}

