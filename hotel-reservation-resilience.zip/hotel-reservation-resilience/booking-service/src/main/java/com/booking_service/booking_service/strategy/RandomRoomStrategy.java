package com.booking_service.booking_service.strategy;

import com.booking_service.booking_service.client.RoomSummary;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

@Component("RANDOM")
public class RandomRoomStrategy implements RoomSelectionStrategy {
    @Override
    public Optional<RoomSummary> select(List<RoomSummary> candidates) {
        if (candidates == null || candidates.isEmpty()) {
            return Optional.empty();
        }
        int idx = ThreadLocalRandom.current().nextInt(candidates.size());
        return Optional.ofNullable(candidates.get(idx));
    }
}

