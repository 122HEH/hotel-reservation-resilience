package com.booking_service.booking_service.strategy;

import com.booking_service.booking_service.client.RoomSummary;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Component("CHEAPEST")
public class CheapestRoomStrategy implements RoomSelectionStrategy {
    @Override
    public Optional<RoomSummary> select(List<RoomSummary> candidates) {
        return candidates.stream().min(Comparator.comparingDouble(RoomSummary::pricePerNight));
    }
}

