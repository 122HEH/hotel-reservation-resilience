package com.booking_service.booking_service.service;

import com.booking_service.booking_service.entity.Booking;

import java.util.List;

public interface BookingUseCase {
    List<Booking> getAllBookings();
    Booking createBooking(Booking booking);
}

