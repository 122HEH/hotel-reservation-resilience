package com.booking_service.booking_service.client;

import java.util.List;

public interface RoomCatalogClient {
    List<RoomSummary> getAvailableRooms(String roomType);
}

