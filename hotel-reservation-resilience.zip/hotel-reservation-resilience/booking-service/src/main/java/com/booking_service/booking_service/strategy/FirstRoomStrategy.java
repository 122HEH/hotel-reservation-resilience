package com.booking_service.booking_service.strategy;

import com.booking_service.booking_service.client.RoomSummary;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component("FIRST")
public class FirstRoomStrategy implements RoomSelectionStrategy {
    @Override
    public Optional<RoomSummary> select(List<RoomSummary> candidates) {
        return candidates.stream().findFirst();
    }
}

