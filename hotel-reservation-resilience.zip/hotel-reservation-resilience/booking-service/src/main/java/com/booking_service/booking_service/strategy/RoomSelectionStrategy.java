package com.booking_service.booking_service.strategy;

import com.booking_service.booking_service.client.RoomSummary;

import java.util.List;
import java.util.Optional;

public interface RoomSelectionStrategy {
    Optional<RoomSummary> select(List<RoomSummary> candidates);
}

