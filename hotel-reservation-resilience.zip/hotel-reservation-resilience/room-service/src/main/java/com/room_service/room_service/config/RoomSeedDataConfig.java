package com.room_service.room_service.config;

import com.room_service.room_service.entity.Room;
import com.room_service.room_service.repository.RoomRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RoomSeedDataConfig {

    @Bean
    CommandLineRunner seedRooms(RoomRepository repository) {
        return args -> {
            if (repository.count() > 0) {
                return;
            }

            repository.save(new Room("single", 80.0, true));
            repository.save(new Room("single", 95.0, true));
            repository.save(new Room("double", 140.0, true));
            repository.save(new Room("double", 160.0, false));
            repository.save(new Room("suite", 320.0, true));
        };
    }
}

