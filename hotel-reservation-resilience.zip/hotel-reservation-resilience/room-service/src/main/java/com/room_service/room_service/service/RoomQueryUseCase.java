package com.room_service.room_service.service;

import com.room_service.room_service.entity.Room;

import java.util.List;

public interface RoomQueryUseCase {
    List<Room> getAvailableRooms(String type) throws InterruptedException;
}

