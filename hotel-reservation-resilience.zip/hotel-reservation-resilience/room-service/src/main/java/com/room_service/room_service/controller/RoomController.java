package com.room_service.room_service.controller;

import com.room_service.room_service.entity.Room;
import org.springframework.beans.factory.annotation.Value;
import com.room_service.room_service.service.RoomQueryUseCase;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    private final RoomQueryUseCase service;
    private final String serviceName;

    public RoomController(RoomQueryUseCase service, @Value("${spring.application.name}") String serviceName) {
        this.service = service;
        this.serviceName = serviceName;
    }

    @GetMapping("/available")
    public List<Room> getAvailable(@RequestParam(required = false) String type) throws InterruptedException {
        return service.getAvailableRooms(type);
    }

    @GetMapping("/ping")
    public String ping() {
        return "Réponse de " + serviceName;
    }
    // room creation stays in repository layer; booking-service focuses on querying availability
}