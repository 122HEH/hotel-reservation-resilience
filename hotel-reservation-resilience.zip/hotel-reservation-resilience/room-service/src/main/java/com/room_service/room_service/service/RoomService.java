package com.room_service.room_service.service;


import com.room_service.room_service.entity.Room;
import com.room_service.room_service.repository.RoomRepository;
import io.github.resilience4j.bulkhead.BulkheadFullException;
import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Locale;

@Service
public class RoomService implements RoomQueryUseCase {

    private final RoomRepository repository;
    private final String serviceName;

    public RoomService(RoomRepository repository, @Value("${spring.application.name}") String serviceName) {
        this.repository = repository;
        this.serviceName = serviceName;
    }

    @Bulkhead(name = "roomService", fallbackMethod = "fallbackRooms")
    @Override
    public List<Room> getAvailableRooms(String type) throws InterruptedException {
        Thread.sleep(70);
        String normalizedType = type == null ? "" : type.trim().toLowerCase(Locale.ROOT);
        return repository.findAll().stream()
                .filter(Room::isAvailable)
                .filter(r -> normalizedType.isBlank() || (r.getType() != null && r.getType().toLowerCase(Locale.ROOT).equals(normalizedType)))
                .toList();
    }

    public List<Room> fallbackRooms(String type, BulkheadFullException e) {
        System.err.println("[" + serviceName + "] Bulkhead saturé !");
        return List.of();
    }
}