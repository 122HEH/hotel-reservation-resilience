package com.room_service.room_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
