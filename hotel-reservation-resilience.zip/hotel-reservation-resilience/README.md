## Hotel Reservation Resilience (Spring Boot Microservices)

Deux microservices Spring Boot qui démontrent des patterns de résilience **sans reprendre un “order/inventory”** :

- **`room-service`**: catalogue des chambres (H2 + JPA) avec **Bulkhead**.
- **`booking-service`**: réservations (H2 + JPA) qui appelle `room-service` via REST avec **Retry + CircuitBreaker**, et applique **Strategy + Factory + DIP** pour sélectionner une chambre.

### Architecture (couches)

Chaque service suit la structure:

- **controller** (REST)
- **service** (use cases / logique)
- **repository** (JPA)
- **entity** (domaine)
- (booking-service) **client** + **strategy** + **factory**

### Endpoints

#### room-service (port 8082)

- `GET /api/rooms/available?type=single|double|suite`
- `GET /api/rooms/ping`
- `GET /actuator/health`
- `GET /actuator/bulkheads`

#### booking-service (port 8081)

- `GET /api/bookings`
- `POST /api/bookings` (body: `guestName`, `roomType`, `nights`)
- `GET /api/bookings/fail` (simule une panne pour ouvrir le circuit)
- `GET /actuator/health`
- `GET /actuator/circuitbreakers`
- `GET /actuator/retries`

### Lancer localement

Dans deux terminaux:

```bash
cd room-service
./mvnw spring-boot:run
```

```bash
cd booking-service
./mvnw spring-boot:run
```

### Config utile

- `booking-service/src/main/resources/application.yml`
  - `room-service.base-url` (par défaut `http://localhost:8082`)
  - `booking.room-selection-strategy` = `CHEAPEST` | `RANDOM` | `FIRST`

