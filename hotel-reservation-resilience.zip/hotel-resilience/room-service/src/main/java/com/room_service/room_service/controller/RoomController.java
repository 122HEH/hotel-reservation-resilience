package com.room_service.room_service.controller;

import com.room_service.room_service.entity.Room;
import com.room_service.room_service.repository.RoomRepository;
import com.room_service.room_service.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {
    @Autowired
    private RoomRepository repository;

    @Autowired
    private RoomService service;

    @Value("${spring.application.name}")
    private String serviceName;

    @GetMapping
    public List<Room> getAvailable() throws InterruptedException {
        return service.getAvailableRooms();
    }

    @GetMapping("/ping")
    public String ping() {
        return "Réponse de " + serviceName;
    }
    @PostMapping
    public Room create(@RequestBody Room room) {
        return repository.save(room);
    }
}