package com.room_service.room_service.service;


import com.room_service.room_service.entity.Room;
import com.room_service.room_service.repository.RoomRepository;
import io.github.resilience4j.bulkhead.BulkheadFullException;
import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoomService {

    @Autowired
    private RoomRepository repository;

    @Value("${spring.application.name}")
    private String serviceName;

    @Bulkhead(name = "roomService", fallbackMethod = "fallbackRooms")
    public List<Room> getAvailableRooms() throws InterruptedException {
        Thread.sleep(70);
        return repository.findAll();
    }

    public List<Room> fallbackRooms(BulkheadFullException e) {
        System.err.println("[" + serviceName + "] Bulkhead saturé !");
        return List.of();
    }
}