package com.booking_service.booking_service.service;



import com.booking_service.booking_service.entity.Booking;
import com.booking_service.booking_service.repository.BookingRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository repository;

    @Value("${spring.application.name}")
    private String serviceName;

    @CircuitBreaker(name = "bookingService", fallbackMethod = "fallbackGetAll")
    public List<Booking> getAllBookings() {
        return repository.findAll();
    }

    @CircuitBreaker(name = "bookingService", fallbackMethod = "fallbackSave")
    public Booking createBooking(Booking booking) {
        return repository.save(booking);
    }

    public List<Booking> fallbackGetAll(Throwable t) {
        System.err.println("[" + serviceName + "] Circuit Breaker : " + t.getMessage());
        return List.of();
    }

    public Booking fallbackSave(Booking b, Throwable t) {
        System.err.println("[" + serviceName + "] Circuit Breaker sur création.");
        return null;
    }
}