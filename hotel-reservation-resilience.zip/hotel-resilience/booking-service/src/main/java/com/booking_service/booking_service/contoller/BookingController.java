package com.booking_service.booking_service.contoller;


import com.booking_service.booking_service.entity.Booking;
import com.booking_service.booking_service.service.BookingService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService service;

    @Value("${spring.application.name}")
    private String serviceName;

    @GetMapping
    public List<Booking> getAll() {
        return service.getAllBookings();
    }

    @PostMapping
    public Booking create(@RequestBody Booking booking) {
        return service.createBooking(booking);
    }

    @GetMapping("/ping")
    public String ping() {
        return "Réponse de " + serviceName + " [CIRCUIT FERMÉ]";
    }
    @GetMapping("/fail")
    @CircuitBreaker(name = "bookingService", fallbackMethod = "fallbackFail")
    public String fail() {
        throw new RuntimeException("Panne simulée !");
    }

    public String fallbackFail(Throwable t) {
        return "FALLBACK — Circuit Breaker OUVERT !";
    }
}

