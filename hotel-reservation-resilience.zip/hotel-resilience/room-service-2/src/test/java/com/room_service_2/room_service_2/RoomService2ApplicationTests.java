package com.room_service_2.room_service_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomService2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
