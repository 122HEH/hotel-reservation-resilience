package com.room_service_2.room_service_2.contoller;


import com.room_service_2.room_service_2.entity.Room;
import com.room_service_2.room_service_2.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    @Autowired
    private RoomService service;

    @Value("${spring.application.name}")
    private String serviceName;

    @GetMapping
    public List<Room> getAvailable() {
        return service.getAvailableRooms();
    }

    @GetMapping("/ping")
    public String ping() {
        return "Réponse de " + serviceName;
    }
}