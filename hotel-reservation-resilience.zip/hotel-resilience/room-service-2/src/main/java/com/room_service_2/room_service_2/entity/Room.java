package com.room_service_2.room_service_2.entity;


import jakarta.persistence.*;

@Entity
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String type;
    private double pricePerNight;
    private boolean available;

    public Room() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getType() { return type; }
    public void setType(String t) { this.type = t; }
    public double getPricePerNight() { return pricePerNight; }
    public void setPricePerNight(double p) { this.pricePerNight = p; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean a) { this.available = a; }
}