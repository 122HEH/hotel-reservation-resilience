package com.room_service_2.room_service_2.repository;

import com.room_service_2.room_service_2.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRepository extends JpaRepository<Room, Long> {
}