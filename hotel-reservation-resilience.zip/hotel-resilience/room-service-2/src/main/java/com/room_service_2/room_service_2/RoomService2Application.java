package com.room_service_2.room_service_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomService2Application {

	public static void main(String[] args) {
		SpringApplication.run(RoomService2Application.class, args);
	}

}
