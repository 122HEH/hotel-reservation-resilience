package com.room_service_2.room_service_2.service;


import com.room_service_2.room_service_2.entity.Room;
import com.room_service_2.room_service_2.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoomService {

    @Autowired
    private RoomRepository repository;

    @Value("${spring.application.name}")
    private String serviceName;

    public List<Room> getAvailableRooms() {
        return repository.findAll();
    }
}