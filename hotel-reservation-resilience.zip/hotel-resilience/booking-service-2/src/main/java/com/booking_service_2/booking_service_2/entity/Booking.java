package com.booking_service_2.booking_service_2.entity;

import jakarta.persistence.*;

@Entity
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String guestName;
    private String roomType;
    private int nights;

    public Booking() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getGuestName() { return guestName; }
    public void setGuestName(String g) { this.guestName = g; }
    public String getRoomType() { return roomType; }
    public void setRoomType(String r) { this.roomType = r; }
    public int getNights() { return nights; }
    public void setNights(int n) { this.nights = n; }
}