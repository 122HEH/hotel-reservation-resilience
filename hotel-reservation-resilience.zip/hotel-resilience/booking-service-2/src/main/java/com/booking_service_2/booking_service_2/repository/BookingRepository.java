package com.booking_service_2.booking_service_2.repository;


import com.booking_service_2.booking_service_2.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {
}