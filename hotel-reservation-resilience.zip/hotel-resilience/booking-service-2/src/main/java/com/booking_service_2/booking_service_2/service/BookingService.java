package com.booking_service_2.booking_service_2.service;


import com.booking_service_2.booking_service_2.entity.Booking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.booking_service_2.booking_service_2.repository.BookingRepository;

import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository repository;

    @Value("${spring.application.name}")
    private String serviceName;

    public List<Booking> getAllBookings() {
        return repository.findAll();
    }

    public Booking createBooking(Booking booking) {
        return repository.save(booking);
    }
}