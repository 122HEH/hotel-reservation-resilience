package com.booking_service_2.booking_service_2.controller;


import com.booking_service_2.booking_service_2.entity.Booking;
import com.booking_service_2.booking_service_2.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
        import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService service;

    @Value("${spring.application.name}")
    private String serviceName;

    @GetMapping
    public List<Booking> getAll() {
        return service.getAllBookings();
    }

    @PostMapping
    public Booking create(@RequestBody Booking booking) {
        return service.createBooking(booking);
    }

    @GetMapping("/ping")
    public String ping() {
        return "Réponse de " + serviceName + " [CIRCUIT FERMÉ]";
    }
}