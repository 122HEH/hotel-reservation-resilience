package com.booking_service_2.booking_service_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingService2Application {

	public static void main(String[] args) {
		SpringApplication.run(BookingService2Application.class, args);
	}

}
