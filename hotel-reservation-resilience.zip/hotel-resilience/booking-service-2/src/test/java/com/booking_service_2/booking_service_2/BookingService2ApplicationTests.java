package com.booking_service_2.booking_service_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingService2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
